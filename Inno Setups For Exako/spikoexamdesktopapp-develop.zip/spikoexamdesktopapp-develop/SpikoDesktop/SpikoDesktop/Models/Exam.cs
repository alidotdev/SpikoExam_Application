﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpikoDesktop
{
    public class Exam
    {
        public int Id
        {
            get; set;
        }
        public String ExamName
        {
            get; set;
        }
        public String ExamCode
        {
            get; set;
        }
        public int Status
        {
            get; set;
        }


    }
}
